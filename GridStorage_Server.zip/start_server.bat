@echo off
color 0B
echo ===================================================
echo        GridStorage Server - Startup Script
echo ===================================================
echo.

echo [1/3] Checking if Docker is running...
docker info >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo [ERROR] Docker is not running or not installed!
    echo Please start Docker Desktop and run this script again.
    echo.
    pause
    exit /b
)

echo [2/3] Starting the GridStorage Server...
docker-compose up -d

echo.
echo [3/3] Fetching your Local IP Address...
echo ===================================================
color 0A
echo [SUCCESS] Your server is starting up!
echo ===================================================
echo.
echo Please wait ~20 seconds for the database to fully initialize.
echo.
echo Enter this Server URL into your mobile app:
echo.
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address" /c:"IPv4"') do (
    echo    http://%%a:3000
)
echo.
echo Default Login: admin@gridstorage.com
echo Default Pass: admin123
echo.
echo You can now close this window.
pause