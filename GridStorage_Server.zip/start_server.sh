#!/bin/bash
echo "==================================================="
echo "       GridStorage Server - Startup Script"
echo "==================================================="
echo ""

# Sprawdzenie czy Docker dziala
if ! docker info > /dev/null 2>&1; then
  echo "[ERROR] Docker is not running or not installed!"
  echo "Please start Docker Desktop and run this script again."
  exit 1
fi

echo "Starting the GridStorage Server..."
docker-compose up -d

echo ""
echo "==================================================="
echo "[SUCCESS] Your server is starting up!"
echo "==================================================="
echo ""
echo "Please wait ~20 seconds for the database to fully initialize."
echo ""
echo "Your Local IP Addresses (Add http:// before and :3000 after):"
ifconfig | grep "inet " | grep -Fv 127.0.0.1 | awk '{print $2}'
echo ""
echo "Default Login: admin@gridstorage.com"
echo "Default Pass: admin123"
echo ""