===========================================================
      GRIDSTORAGE ENTERPRISE DATA NODE - CLIENT README
===========================================================

Welcome to your private inventory cluster! 

1. HOW TO START THE SERVER:
   - Windows Laptop/Server: Double-click 'start_server.bat'
   - Mac/Linux/QNAP: Run 'bash start_server.sh' in terminal

2. ACCESSING YOUR SERVICES:
   - Mobile Sync Target URL: http://<YOUR_SERVER_IP>:3000
   - Desktop Web Dashboard:  http://<YOUR_SERVER_IP>:8080

3. UNLOCKING THE PREMIUM WEB DASHBOARD EXTENSION:
   If you purchased the standalone Web Dashboard add-on, copy the 
   compiled files directly into the '/web' folder inside this 
   directory. 

   *QNAP Alternative Setup: You can optionally copy the web files 
   directly into your QNAP's system 'Web' shared folder inside a 
   subfolder named 'grid' and access it via http://<QNAP_IP>/grid/