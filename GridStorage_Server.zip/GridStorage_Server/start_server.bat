@echo off
color 0B
echo ===================================================
echo        GridStorage Server - Startup Script
echo ===================================================
echo.

echo [1/4] Ensuring local directories exist...
if not exist "web" (
    mkdir "web"
    echo Created premium web directory folder.
)

echo [2/4] Checking if Docker is running...
docker info >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo [ERROR] Docker is not running or not installed!
    echo Please start Docker Desktop and run this script again.
    echo.
    pause
    exit /b
)

echo [3/4] Starting the GridStorage Server...
docker-compose up -d

echo.
echo [4/4] Fetching your Local IP Address...
echo ===================================================
color 0A
echo [SUCCESS] Your server is starting up!
echo ===================================================
echo.
echo Please wait ~20 seconds for the database to fully initialize.
echo.
echo [MOBILE APP URL]
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address" /c:"IPv4"') do (
    echo    http://%%a:3000
)
echo.
echo [WEB DASHBOARD URL]
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address" /c:"IPv4"') do (
    echo    http://%%a:8080
)
echo.
echo Default Login: admin@gridstorage.com
echo Default Pass: admin123
echo.
echo You can now close this window.
pause