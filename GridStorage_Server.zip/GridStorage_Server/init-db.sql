DO $$ BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'web_anon') THEN CREATE ROLE web_anon NOLOGIN; END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'api_user') THEN CREATE ROLE api_user NOLOGIN; END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'admin') THEN CREATE ROLE admin NOLOGIN; END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'user') THEN CREATE ROLE "user" NOLOGIN; END IF;
END $$;

CREATE EXTENSION IF NOT EXISTS pgcrypto SCHEMA public;

CREATE TABLE IF NOT EXISTS public.app_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    pass TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS public.storage_boxes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "userId" UUID REFERENCES public.app_users(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    quantity INTEGER DEFAULT 0,
    threshold INTEGER DEFAULT 0,
    hex_color TEXT DEFAULT '#FFFFFF',
    model_path TEXT,
    last_used TIMESTAMP DEFAULT NOW(),
    barcode TEXT,
    image_base64 TEXT,
    image_path TEXT, -- <--- KRYTYCZNA POPRAWKA: Dodana brakująca kolumna, o którą prosi Flutter
    notes TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    last_notified_at TIMESTAMP
);

GRANT USAGE ON SCHEMA public TO web_anon, api_user, admin, "user";
GRANT ALL ON ALL TABLES IN SCHEMA public TO api_user, admin, "user";
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO api_user, admin, "user";
GRANT SELECT ON public.storage_boxes TO web_anon;

CREATE OR REPLACE FUNCTION public.sign_jwt(payload json) RETURNS text AS $$
DECLARE
    header text := '{"alg":"HS256","typ":"JWT"}';
    secret text := 'my_very_secure_jwt_secret_key_123456789'; 
    header_base64 text;
    payload_base64 text;
    signature bytea;
    signature_base64 text;
BEGIN
    header_base64 := replace(replace(replace(replace(replace(encode(header::bytea, 'base64'), E'\n', ''), E'\r', ''), '=', ''), '+', '-'), '/', '_');
    payload_base64 := replace(replace(replace(replace(replace(encode(payload::text::bytea, 'base64'), E'\n', ''), E'\r', ''), '=', ''), '+', '-'), '/', '_');
    signature := hmac((header_base64 || '.' || payload_base64)::bytea, secret::bytea, 'sha256'::name);
    signature_base64 := replace(replace(replace(replace(replace(encode(signature, 'base64'), E'\n', ''), E'\r', ''), '=', ''), '+', '-'), '/', '_');
    
    RETURN header_base64 || '.' || payload_base64 || '.' || signature_base64;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION public.login(email TEXT, pass TEXT)
RETURNS json AS $$
DECLARE
    user_record public.app_users;
    token TEXT;
BEGIN
    SELECT * INTO user_record FROM public.app_users u WHERE u.email = login.email AND u.pass = crypt(login.pass, u.pass);
    IF user_record.id IS NULL THEN RAISE EXCEPTION 'Invalid email or password'; END IF;
    
    token := public.sign_jwt(json_build_object(
        'role', user_record.role, 
        'sub', user_record.id,
        'userId', user_record.id,
        'email', user_record.email, 
        'exp', extract(epoch from now() + interval '30 days')::integer
    ));
    
    RETURN json_build_object('token', token, 'role', user_record.role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.login(TEXT, TEXT) TO web_anon;

INSERT INTO public.app_users (email, pass, role) 
VALUES ('admin@gridstorage.com', crypt('admin123', gen_salt('bf')), 'admin')
ON CONFLICT (email) DO NOTHING;