#!/bin/bash
echo "==================================================="
echo "       GridStorage Server - Startup Script"
echo "==================================================="
echo ""

echo "[1/4] Ensuring local directories exist..."
if [ ! -d "web" ]; then
  mkdir -p "web"
  chmod 777 "web"
  echo "Created web directory folder with write permissions."
fi

# Sprawdzenie czy Docker dziala
echo "[2/4] Checking if Docker is running..."
if ! docker info > /dev/null 2>&1; then
  echo "[ERROR] Docker is not running or not installed!"
  echo "Please start Docker Desktop and run this script again."
  exit 1
fi

echo "[3/4] Starting the GridStorage Server..."
docker-compose up -d

echo ""
echo "==================================================="
echo "[SUCCESS] Your server is starting up!"
echo "==================================================="
echo ""
echo "Please wait ~20 seconds for the database to fully initialize."
echo ""

echo "[MOBILE APP URL] (Port 3000):"
ifconfig | grep "inet " | grep -Fv 127.0.0.1 | awk '{print "   http://"$2":3000"}'
echo ""

echo "[WEB DASHBOARD URL] (Port 8080):"
ifconfig | grep "inet " | grep -Fv 127.0.0.1 | awk '{print "   http://"$2":8080"}'
echo ""

echo "Default Login: admin@gridstorage.com"
echo "Default Pass: admin123"
echo ""